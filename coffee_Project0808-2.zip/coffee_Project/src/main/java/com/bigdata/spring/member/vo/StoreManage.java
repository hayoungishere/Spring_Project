package com.bigdata.spring.member.vo                                                      ;

public class StoreManage {

	private StoreManageVO smvo;
	public StoreManageVO getSm() {
		return smvo;
	}
	
	public void setSm(StoreManageVO sm) {
		this.smvo=sm;
	}
	
}
