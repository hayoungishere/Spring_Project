package com.bigdata.spring.member.vo;

public class menu {
	private MenuVO menuVo;
	public MenuVO getMenu() {
		return menuVo;
	}
	
	public void setSm(MenuVO menuVo) {
		this.menuVo=menuVo;
	}
}
