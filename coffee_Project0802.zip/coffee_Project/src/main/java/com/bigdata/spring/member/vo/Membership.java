package com.bigdata.spring.member.vo;



public class Membership {
	private MembershipVO mvo;
	
	public MembershipVO getMvo() {
		return mvo;
	}
	public void setMvo(MembershipVO mvo) {
		this.mvo=mvo;
	}
	
	
}
