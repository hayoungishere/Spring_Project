package com.bigdata.spring.member.vo;

public class Member {
	private MemberVO mvo;

	public MemberVO getMvo() {
		return mvo;
	}

	public void setMvo(MemberVO mvo) {
		this.mvo = mvo;
	}
	
	
}
